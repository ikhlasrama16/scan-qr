<img src="{{ asset('images/LOGO BDW POLOSAN.png') }}" alt="Logo" class="h-14 object-contain mx-auto"
    style="max-width: 220px;" />
