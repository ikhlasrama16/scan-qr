<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100 flex flex-col items-center justify-center text-center">
                    <p class="mb-4">Selamat datang, <?php echo e(Auth::user()->name); ?>!</p>

                    <div class="w-full max-w-md">
                        <h3 class="text-lg font-bold mb-4">Scan QR Code</h3>

                        <div id="reader" class="mx-auto" style="width: 300px;"></div>

                        <!-- Modal -->
                        <div id="qrModal"
                            class="fixed z-50 inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden">
                            <div class="bg-white rounded-lg p-6 w-full max-w-md shadow-lg">
                                <h2 class="text-xl font-bold mb-4 text-gray-800">Isi Keterangan</h2>
                                <input type="hidden" id="lokasi_scan" />
                                <textarea id="keterangan" rows="4" class="w-full border rounded p-2 text-gray-800"
                                    placeholder="Masukkan keterangan tambahan..."></textarea>
                                <div class="mt-4 flex justify-end gap-2">
                                    <button onclick="closeModal()" class="px-4 py-2 bg-gray-300 text-black rounded">
                                        Batal
                                    </button>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['onclick' => 'submitQrLog()','type' => 'button']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'submitQrLog()','type' => 'button']); ?>
                                        Kirim
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>



                                </div>

                            </div>
                        </div>


                        <div class="mt-4 text-left">
                            <label class="block text-sm mb-1">Hasil QR Code:</label>
                            <input type="hidden" id="lokasi_scan" name="lokasi_scan">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        const qrResultInput = document.getElementById('qr-result');

        function onScanSuccess(decodedText, decodedResult) {
            // simpan hasil scan ke input hidden
            document.getElementById('lokasi_scan').value = decodedText;

            // tampilkan modal
            document.getElementById('qrModal').classList.remove('hidden');

            document.getElementById('lokasi_scan').value = decodedText;
            document.getElementById('qr-preview').innerText = decodedText;


            // stop scanner (opsional agar tidak terus scan)
            html5QrcodeScanner.clear();
        }


        function closeModal() {
            document.getElementById('qrModal').classList.add('hidden');
        }

        function submitQrLog() {
            const lokasiScan = document.getElementById('lokasi_scan').value;
            const keterangan = document.getElementById('keterangan').value;

            fetch("<?php echo e(url('/log-qr')); ?>", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    },
                    body: JSON.stringify({
                        lokasi_scan: lokasiScan,
                        keterangan: keterangan
                    })
                })
                .then(async response => {
                    const text = await response.text();
                    if (!response.ok) throw new Error(text);
                    return JSON.parse(text);
                })
                .then(data => {
                    alert("Data QR berhasil dikirim!");
                    closeModal();
                })
                .catch(error => {
                    alert("Gagal mengirim data QR: " + error.message);
                });
            console.log("KETERANGAN:", keterangan);

        }


        const html5QrcodeScanner = new Html5QrcodeScanner("reader", {
            fps: 10,
            qrbox: 250
        });
        html5QrcodeScanner.render(onScanSuccess);
    </script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\test-webapp\scan-qr\resources\views/dashboard.blade.php ENDPATH**/ ?>